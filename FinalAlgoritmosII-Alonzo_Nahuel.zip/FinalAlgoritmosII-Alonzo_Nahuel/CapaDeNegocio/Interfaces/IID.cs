﻿

namespace CapaDeNegocio
{
    internal interface IID
    {
        int ID { get; set; }
    }
}
